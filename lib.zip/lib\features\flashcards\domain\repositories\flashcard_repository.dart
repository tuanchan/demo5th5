abstract class FlashcardRepository {}
