abstract class StatisticsRepository {}
