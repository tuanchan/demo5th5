abstract class SettingsRepository {}
