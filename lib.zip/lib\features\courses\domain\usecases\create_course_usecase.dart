class CreateCourseUseCase {
  const CreateCourseUseCase();
}
