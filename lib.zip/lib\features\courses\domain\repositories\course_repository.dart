abstract class CourseRepository {}
